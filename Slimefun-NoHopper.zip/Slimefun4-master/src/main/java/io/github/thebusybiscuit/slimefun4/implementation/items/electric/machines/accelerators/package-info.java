/**
 * This package contains any electric machines related to growth accelerations.
 * These growth accelerators speed up the growth of animals or plants.
 */
package io.github.thebusybiscuit.slimefun4.implementation.items.electric.machines.accelerators; 