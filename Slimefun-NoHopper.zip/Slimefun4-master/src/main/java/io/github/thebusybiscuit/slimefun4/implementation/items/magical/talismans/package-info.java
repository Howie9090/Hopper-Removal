/**
 * This package holds any {@link io.github.thebusybiscuit.slimefun4.api.items.SlimefunItem} related to the
 * {@link io.github.thebusybiscuit.slimefun4.implementation.items.magical.talismans.Talisman}.
 */
package io.github.thebusybiscuit.slimefun4.implementation.items.magical.talismans;