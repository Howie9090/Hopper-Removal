/**
 * This package holds classes related to the
 * {@link io.github.thebusybiscuit.slimefun4.core.services.sounds.SoundService}.
 * This service is responsible for our sound management and allowing server owners to fully customize
 * their sound experience.
 */
package io.github.thebusybiscuit.slimefun4.core.services.sounds;