/**
 * This package stores API-related classes that are related to a {@link org.bukkit.entity.Player},
 * such as the {@link io.github.thebusybiscuit.slimefun4.api.player.PlayerProfile} for example.
 */
package io.github.thebusybiscuit.slimefun4.api.player;