/**
 * This package holds implementations of {@link io.github.thebusybiscuit.slimefun4.api.items.SlimefunItem}
 * that are related to food.
 */
package io.github.thebusybiscuit.slimefun4.implementation.items.food;