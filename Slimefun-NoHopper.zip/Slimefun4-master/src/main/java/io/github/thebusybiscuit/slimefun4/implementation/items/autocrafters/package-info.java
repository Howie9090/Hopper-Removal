/**
 * This package contains any electric machines related to automatic crafting tables.
 */
package io.github.thebusybiscuit.slimefun4.implementation.items.autocrafters;