/**
 * This package contains the core system for the {@link io.github.thebusybiscuit.slimefun4.core.guide.SlimefunGuide}.
 * Note that you can find the individual implementations of the guide, in the implementation package
 */
package io.github.thebusybiscuit.slimefun4.core.guide;