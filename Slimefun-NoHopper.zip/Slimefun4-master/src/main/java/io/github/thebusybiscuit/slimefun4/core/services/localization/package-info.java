/**
 * This package contains everything related to translations and localization.
 */
package io.github.thebusybiscuit.slimefun4.core.services.localization;