/**
 * This package holds classes associated with the
 * {@link io.github.thebusybiscuit.slimefun4.implementation.items.multiblocks.miner.IndustrialMiner}.
 */
package io.github.thebusybiscuit.slimefun4.implementation.items.multiblocks.miner;