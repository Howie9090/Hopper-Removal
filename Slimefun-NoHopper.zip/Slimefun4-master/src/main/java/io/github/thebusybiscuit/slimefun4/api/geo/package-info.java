/**
 * This package contains classes that are centered around the
 * {@link io.github.thebusybiscuit.slimefun4.api.geo.GEOResource} API.
 */
package io.github.thebusybiscuit.slimefun4.api.geo;