/**
 * This package contains the different implementations of
 * {@link me.mrCookieSlime.Slimefun.Objects.SlimefunItem.abstractItems.AGenerator}.
 */
package io.github.thebusybiscuit.slimefun4.implementation.items.electric.generators;