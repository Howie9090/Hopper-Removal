/**
 * This package contains the Settings menu for the {@link io.github.thebusybiscuit.slimefun4.core.guide.SlimefunGuide} as
 * well as the interface {@link io.github.thebusybiscuit.slimefun4.core.guide.options.SlimefunGuideOption} for adding
 * your own options
 */
package io.github.thebusybiscuit.slimefun4.core.guide.options;