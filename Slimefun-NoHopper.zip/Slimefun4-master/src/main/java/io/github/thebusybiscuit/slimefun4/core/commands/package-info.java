/**
 * This package contains everything related to Slimefun's ingame command.
 */
package io.github.thebusybiscuit.slimefun4.core.commands;