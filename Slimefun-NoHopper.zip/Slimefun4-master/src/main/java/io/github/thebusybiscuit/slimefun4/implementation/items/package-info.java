/**
 * This package contains the different classes for each
 * {@link io.github.thebusybiscuit.slimefun4.api.items.SlimefunItem}
 */
package io.github.thebusybiscuit.slimefun4.implementation.items;