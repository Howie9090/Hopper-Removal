/**
 * This package contains a few miscellaneous implementations of
 * {@link io.github.thebusybiscuit.slimefun4.api.items.SlimefunItem} which are blocks.
 * Such as the {@link io.github.thebusybiscuit.slimefun4.implementation.items.blocks.BlockPlacer} for example.
 */
package io.github.thebusybiscuit.slimefun4.implementation.items.blocks;