/**
 * This package contains implementations of {@link io.github.thebusybiscuit.slimefun4.api.items.SlimefunItem} that are
 * related to armor, such as the expandable
 * {@link io.github.thebusybiscuit.slimefun4.implementation.items.armor.SlimefunArmorPiece} class for example.
 */
package io.github.thebusybiscuit.slimefun4.implementation.items.armor;