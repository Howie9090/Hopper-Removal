/**
 * This package holds all core mechanics related to a
 * {@link io.github.thebusybiscuit.slimefun4.core.multiblocks.MultiBlock}, like that class itself.
 */
package io.github.thebusybiscuit.slimefun4.core.multiblocks;