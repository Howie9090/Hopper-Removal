/**
 * This package contains all variations of {@link io.github.thebusybiscuit.slimefun4.core.attributes.ItemAttribute} that
 * can be assigned to a {@link io.github.thebusybiscuit.slimefun4.api.items.SlimefunItem}
 */
package io.github.thebusybiscuit.slimefun4.core.attributes;