/**
 * This package contains all the different implementations of
 * {@link io.github.thebusybiscuit.slimefun4.core.multiblocks.MultiBlockMachine}
 */
package io.github.thebusybiscuit.slimefun4.implementation.items.multiblocks;