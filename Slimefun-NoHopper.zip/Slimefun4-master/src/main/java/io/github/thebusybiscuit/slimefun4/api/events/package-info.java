/**
 * This package contains all extensions of {@link org.bukkit.event.Event} that Slimefun provides
 * and allows you to listen to.
 */
package io.github.thebusybiscuit.slimefun4.api.events;