/**
 * This package holds an implementation of {@link io.github.thebusybiscuit.slimefun4.api.network.Network}
 * that is responsible for item transportation.
 */
package io.github.thebusybiscuit.slimefun4.core.networks.cargo;