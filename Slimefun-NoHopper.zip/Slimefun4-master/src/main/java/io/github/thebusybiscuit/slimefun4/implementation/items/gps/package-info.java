/**
 * This package holds implementations of {@link io.github.thebusybiscuit.slimefun4.api.items.SlimefunItem}
 * that are related to the {@link io.github.thebusybiscuit.slimefun4.api.gps.GPSNetwork}.
 */
package io.github.thebusybiscuit.slimefun4.implementation.items.gps;