/**
 * This package contains a few {@link io.github.thebusybiscuit.slimefun4.api.items.ItemGroup} variations.
 */
package io.github.thebusybiscuit.slimefun4.api.items.groups;