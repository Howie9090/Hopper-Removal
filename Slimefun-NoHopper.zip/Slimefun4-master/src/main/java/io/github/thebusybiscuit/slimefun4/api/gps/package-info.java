/**
 * This package stores classes of the API that are related to the
 * {@link io.github.thebusybiscuit.slimefun4.api.gps.GPSNetwork}.
 */
package io.github.thebusybiscuit.slimefun4.api.gps;