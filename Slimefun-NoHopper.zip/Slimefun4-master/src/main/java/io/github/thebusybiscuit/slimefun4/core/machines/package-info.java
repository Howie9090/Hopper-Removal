/**
 * This package contains sources related to the
 * {@link io.github.thebusybiscuit.slimefun4.core.machines.MachineProcessor}
 * and any {@link io.github.thebusybiscuit.slimefun4.core.machines.MachineOperation}.
 */
package io.github.thebusybiscuit.slimefun4.core.machines;