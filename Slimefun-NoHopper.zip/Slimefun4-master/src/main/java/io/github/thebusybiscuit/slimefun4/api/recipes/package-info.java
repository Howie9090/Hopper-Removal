/**
 * This package contains all classes related to our recipe system.
 */
package io.github.thebusybiscuit.slimefun4.api.recipes;