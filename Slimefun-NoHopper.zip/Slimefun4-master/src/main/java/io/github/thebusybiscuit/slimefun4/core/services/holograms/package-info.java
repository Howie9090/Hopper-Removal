/**
 * This package contains everything related to the
 * {@link io.github.thebusybiscuit.slimefun4.core.services.holograms.HologramsService}.
 */
package io.github.thebusybiscuit.slimefun4.core.services.holograms;