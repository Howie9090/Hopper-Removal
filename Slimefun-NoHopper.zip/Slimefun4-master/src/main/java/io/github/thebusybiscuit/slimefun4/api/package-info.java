/**
 * This package contains a bunch of classes and sub-packages related to the interaction
 * with Slimefun via an API.
 */
package io.github.thebusybiscuit.slimefun4.api;