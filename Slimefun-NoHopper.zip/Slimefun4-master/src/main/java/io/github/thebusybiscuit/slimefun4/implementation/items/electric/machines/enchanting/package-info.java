/**
 * This package contains any electric machines related to enchanting.
 * Prominent examples are the
 * {@link io.github.thebusybiscuit.slimefun4.implementation.items.electric.machines.enchanting.AutoEnchanter} and
 * {@link io.github.thebusybiscuit.slimefun4.implementation.items.electric.machines.enchanting.AutoDisenchanter}
 */
package io.github.thebusybiscuit.slimefun4.implementation.items.electric.machines.enchanting;