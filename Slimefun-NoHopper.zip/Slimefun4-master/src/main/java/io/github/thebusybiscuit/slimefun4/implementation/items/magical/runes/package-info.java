/**
 * This package holds any implementation of {@link io.github.thebusybiscuit.slimefun4.api.items.SlimefunItem}
 * that is an ancient rune with functionality.
 */
package io.github.thebusybiscuit.slimefun4.implementation.items.magical.runes;