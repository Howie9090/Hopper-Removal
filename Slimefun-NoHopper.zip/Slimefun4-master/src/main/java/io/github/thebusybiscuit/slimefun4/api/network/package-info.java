/**
 * This package provides the API infrastructure for networks, such as the Cargo- or Energy net.
 */
package io.github.thebusybiscuit.slimefun4.api.network;