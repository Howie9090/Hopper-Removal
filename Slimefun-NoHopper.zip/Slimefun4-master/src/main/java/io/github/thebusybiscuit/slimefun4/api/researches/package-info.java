/**
 * This package holds everything connected to the {@link io.github.thebusybiscuit.slimefun4.api.researches.Research}
 * class.
 */
package io.github.thebusybiscuit.slimefun4.api.researches;